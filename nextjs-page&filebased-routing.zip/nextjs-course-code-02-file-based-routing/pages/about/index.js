function AboutPage() {
    return (
      <div>
        <h1>The About Page</h1>
      </div>
    );
  }
  
  export default AboutPage;